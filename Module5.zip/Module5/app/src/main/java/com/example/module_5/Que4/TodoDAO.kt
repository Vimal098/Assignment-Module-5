package com.example.module_5.Que4

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update

@Dao
interface TodoDAO {

   @Query("select * from todo_table ORDER BY date ASC")
    fun getAllItems():MutableList<Todo>

    @Insert
    fun insertItem(todo: Todo)

    @Delete
    fun deleteItem(todo: Todo)

    @Update
    fun updateItem(todo: Todo)
}