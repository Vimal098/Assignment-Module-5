package com.example.module_5.Activities

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import com.example.module_5.Model.Employee
import com.example.module_5.Network.ApiClient
import com.example.module_5.databinding.ActivitySingleUserDetailBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class SingleUserDetail : AppCompatActivity() {
    private lateinit var binding: ActivitySingleUserDetailBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivitySingleUserDetailBinding.inflate(layoutInflater)
        setContentView(binding.root)

        var userId = intent.getStringExtra("USER_ID")
        userDetail(userId.toString())

    }

    private fun userDetail(userID: String) {

       ApiClient.init().getSingleUserData(5,userID).enqueue(object :Callback<Employee>{
           override fun onResponse(
               call: Call<Employee>,
               response: Response<Employee>
           ) {
               if (response.isSuccessful){
                   var user1 = response.body()
                   user1?.let {
                      binding.tvEmail.text = user1.email
                       binding.tvName.text = user1.name
                       binding.tvMobile.text= user1.contact
                   }
               }
           }

           override fun onFailure(call: Call<Employee>, t: Throwable) {

           }

       })

    }
}