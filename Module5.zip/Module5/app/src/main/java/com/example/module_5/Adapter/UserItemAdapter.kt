package com.example.module_5.Adapter
import android.content.Context
import android.content.Intent
import android.view.LayoutInflater
import android.view.ViewGroup
import android.widget.Toast
import androidx.appcompat.app.AlertDialog
import androidx.recyclerview.widget.RecyclerView
import com.example.module_5.Activities.HomeActivity
import com.example.module_5.Model.DeleteResponse
import com.example.module_5.Model.Employee
import com.example.module_5.Network.ApiClient
import com.example.module_5.databinding.UserItemBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class UserItemAdapter(var context: Context,var employeeList: MutableList<Employee>):
    RecyclerView.Adapter<UserItemAdapter.MyViewHolder>() {
    var itemUpdateClickListener: ((position: Int, employee : Employee) -> Unit)? = null
    var itemCardClickListener: ((position: Int, employee : Employee) -> Unit)? = null


    class MyViewHolder(var binding: UserItemBinding) : RecyclerView.ViewHolder(binding.root){


    }

    override fun onCreateViewHolder(parent: ViewGroup, viewType: Int): MyViewHolder {
        var binding = UserItemBinding.inflate(LayoutInflater.from(context), parent, false)
        return MyViewHolder(binding)
    }

    override fun getItemCount(): Int {
        return employeeList.size
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        var user = employeeList[position]
        holder.binding.etName.text = user.name
        holder.binding.etEmail.text = user.email
        holder.binding.etMobile.text= user.contact
        holder.binding.ivEdit.setOnClickListener {

            itemUpdateClickListener?.invoke(position,user)
        }

        holder.binding.cardView.setOnClickListener {
            itemCardClickListener?.invoke(position,user)

        }

        holder.binding.ivDelete.setOnClickListener {
            showDeleteDialog(position, user)
        }
    }

    private fun showDeleteDialog(position: Int, employee: Employee) {
        val builder = AlertDialog.Builder(context)
        builder.setTitle("Delete")
            .setMessage("Are You Sure Want to Delete this Item?")
            .setPositiveButton("Delete"){
                dialog, which ->
                // User Clicked On "Delete"
                ApiClient.init().deleteUserData(3, employee.id).enqueue(object :Callback<DeleteResponse>{
                    override fun onResponse(
                        call: Call<DeleteResponse>,
                        response: Response<DeleteResponse>
                    ) {
                        if (response.isSuccessful){
                            var res = response.body()
                            if (res!=null){
                                deleteItem(position)
                                Toast.makeText(context, res.message, Toast.LENGTH_SHORT).show()

                                if (res.status == "success"){
                                    context.startActivity(Intent(context, HomeActivity::class.java))
                                }
                            }
                        }
                    }

                    override fun onFailure(call: Call<DeleteResponse>, t: Throwable) {

                    }
                })
            }
            .setNegativeButton("Cancel"){ diaglog , which ->
                // User Clickeed On "Cancel"
                Toast.makeText(context, "Cancelled", Toast.LENGTH_SHORT).show()
            }.create()
            .show()
    }

     fun deleteItem(position: Int) {
        employeeList.removeAt(position)
         notifyItemRemoved(position)
    }
    fun updateList(employeeList: MutableList<Employee>){
        this.employeeList = employeeList
        notifyDataSetChanged()
        Toast.makeText(context, "Data Updated Successfully", Toast.LENGTH_SHORT).show()
    }
}