package com.example.module_5.Que4

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase

@Database(entities = [Todo::class], version = 3)
abstract class
AppDatabase2: RoomDatabase() {

    // abstract method
    abstract fun todoDao():TodoDAO
    companion object {

        private var INSTANCE: AppDatabase2? = null

        fun getInstance(context: Context): AppDatabase2? {
            if (INSTANCE == null) {
                synchronized(this){
                    INSTANCE =
                        Room.databaseBuilder(context, AppDatabase2::class.java, "todo.db").allowMainThreadQueries().build()
                }
            }
            return INSTANCE
        }

    }

}
