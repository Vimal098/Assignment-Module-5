package com.example.module_5.Que3

import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.net.Uri
import android.os.Build
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.util.Log
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import com.example.module_5.Model.Task
import com.example.module_5.R
import com.example.module_5.databinding.ActivityTaskBinding
import java.io.IOException
import java.lang.Exception
import kotlin.concurrent.thread

class TaskActivity : AppCompatActivity() {
    lateinit var binding: ActivityTaskBinding
    var db: AppDatabase? = null
    private var task: Task? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTaskBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = AppDatabase.getInstance(this)

        task = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("task", Task::class.java)
        } else {
            intent.getParcelableExtra("task")
        }

        task?.let {
            // update
            binding.btnAddTask.text = "Update Task"
            binding.etCuisine.setText(it.title)
            binding.etDesc.setText(it.description)
            binding.etDate.setText(it.date)
            binding.etTime.setText(it.time)
            binding.autoPriority.setText(it.priority)
        }

        binding.btnAddTask.setOnClickListener {
            var title = binding.etCuisine.text.toString().trim()
            var desc = binding.etDesc.text.toString().trim()
            var date = binding.etDate.text.toString().trim()
            var time = binding.etTime.text.toString().trim()
            var priority = binding.autoPriority.text.toString()
            updateRecord(title, desc,date,time,priority)
        }

}

    private fun updateRecord(title: String, desc: String, date: String, time: String, priority: String) {

        var message = ""

        thread(start = true) {

            var taskObject = Task(
                title = title,
                description = desc,
                date = date,
                time = time,
                priority = priority,
                id = if (task != null) task!!.id else 0,
                createdAt = if (task != null) task!!.createdAt else System.currentTimeMillis(),
            )

            try {
                if(task!=null){
                    //update
                    db!!.taskDao().updateTask(taskObject)
                    message = "Record updated successfully"
                }else{
                    //add
                    db!!.taskDao().insertTask(taskObject)
                    message = "Record added successfully"
                }

                runOnUiThread {
                    Toast.makeText(this, "$message", Toast.LENGTH_SHORT).show()
                    onBackPressedDispatcher.onBackPressed()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    }

    }
