package com.example.module_5.Model

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize


@Entity(tableName = "task_table")
@Parcelize
data class Task(
@PrimaryKey(autoGenerate = true)
var id: Int= 0,
var title:String,
@ColumnInfo(name = "desc")
var description:String?,
var priority : String,
@ColumnInfo(name = "date")
var date : String,
@ColumnInfo(name = "time")
var time : String,
@ColumnInfo(name = "created_at")
var createdAt:Long= System.currentTimeMillis()
): Parcelable
