package com.example.module_5.Que3

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.module_5.Model.Task

@Database(entities = [Task::class], version = 3)
abstract class AppDatabase: RoomDatabase() {

    // abstract method
    abstract fun taskDao():TaskDAO
    companion object {

        private var INSTANCE: AppDatabase? = null

        fun getInstance(context: Context): AppDatabase? {
            if (INSTANCE == null) {
                synchronized(this){
                    INSTANCE =
                        Room.databaseBuilder(context, AppDatabase::class.java, "task.db").allowMainThreadQueries().build()
                }
            }
            return INSTANCE
        }

    }

}
