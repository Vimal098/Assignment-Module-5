package com.example.module_5.Que3

import android.content.Context
import android.graphics.Color
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.module_5.Model.Task
import com.example.module_5.databinding.TaskItemLayoutBinding

class TaskListAdapter(var context: Context, var taskLIst :MutableList<Task>):
    RecyclerView.Adapter<TaskListAdapter.MyViewHolder>(){
    var itemEditClickListener: ((position: Int, task: Task) -> Unit)? = null
    var itemDeleteClickListener: ((position: Int, task: Task) -> Unit)? = null


    class MyViewHolder(var binding: TaskItemLayoutBinding): RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ):MyViewHolder {
        var binding = TaskItemLayoutBinding.inflate(LayoutInflater.from(context),parent,false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder:MyViewHolder, position: Int) {
        var task = taskLIst[position]
        holder.binding.tvTitle.text = task.title
        holder.binding.tvDescription.text = task.description
        holder.binding.tvDate.text = task.date
        holder.binding.tvTime.text = task.time
        holder.binding.tvPriority.text= task.priority
        var prior = task.priority
        when(prior){
            "High"->{
                holder.binding.background.setBackgroundColor(Color.RED)
            }
            "Average"->{
                holder.binding.background.setBackgroundColor(Color.BLUE)
            }
            "Low"->{
                holder.binding.background.setBackgroundColor(Color.GREEN)
            }
        }
        holder.binding.ivEdit.setOnClickListener {
            itemEditClickListener?.invoke(position, task)
        }

        holder.binding.ivDelete.setOnClickListener {
            itemDeleteClickListener?.invoke(position, task)
        }
    }

    override fun getItemCount(): Int {
        return taskLIst.size
    }

    fun setItems(mutableList: MutableList<Task>) {
        this.taskLIst = mutableList
        notifyDataSetChanged()
    }

    fun deleteItem(position: Int){
        taskLIst.removeAt(position)
        notifyItemRemoved(position)
    }


}
