package com.example.module_5.Que4

import android.os.Parcelable
import androidx.room.ColumnInfo
import androidx.room.Entity
import androidx.room.PrimaryKey
import kotlinx.android.parcel.Parcelize

@Entity(tableName = "todo_table")
@Parcelize
data class Todo(
    @PrimaryKey(autoGenerate = true)
    val id: Int = 0,
    val task: String,
    val date: String,
    @ColumnInfo(name = "created_at")
    var createdAt:Long= System.currentTimeMillis()
): Parcelable


