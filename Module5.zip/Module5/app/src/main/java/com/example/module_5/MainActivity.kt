package com.example.module_5

import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.module_5.Adapter.QuestionListAdapter
import com.example.module_5.Model.Questions
import com.example.module_5.databinding.ActivityMainBinding

class MainActivity : AppCompatActivity() {
    private lateinit var binding : ActivityMainBinding
    private var questionList = mutableListOf<Questions>()
    private lateinit var questionAdapter: QuestionListAdapter
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding= ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        prepareData()
        questionAdapter = QuestionListAdapter(this,questionList)
        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = questionAdapter
    }

    private fun prepareData() {
        questionList.add(
            Questions(
                1, "1. Create an application of todo app using SQLite with function lite to create list of upcoming task, completed task, remove task, update task in daily activity.")
        )
        questionList.add(
            Questions(2,"2. Create a Sticky Notes app with proper customization which can insert,view,update,delete using SQLite database.")
        )
        questionList.add(
            Questions(3, "3. To create task management application for adding, updating, deleting the task and show the tasks in the listview or gridview. Task have name, description, date, time, priority. Sort the task by the date and time wise. If task is due then automatically show as blue color. It will search the tasks by date wise. If high priority then show as red color, average priority as blue color, low priority as green color. Select specified item an open context menu to select “Complete the Task then this task.")
        )
        questionList.add(
            Questions(4, "4. Create an application in which employee can login and register with MySQL database.")
        )
        questionList.add(
            Questions(5, "5. In previous application after logging employee can insert, update and delete project details Create an application to select employee profile page in which employee can upload profile.")
        )
        questionList.add(
            Questions(6, "6. pic selected from gallery or camera after login to application.")
        )
    }
}