package com.example.module_5.Que3

import androidx.room.Dao
import androidx.room.Delete
import androidx.room.Insert
import androidx.room.Query
import androidx.room.Update
import com.example.module_5.Model.Task

@Dao
interface TaskDAO {
    @Insert
    fun insertTask(task: Task)

    @Query("select * from task_table ORDER BY date ASC, time ASC")
    fun getAllTask():MutableList<Task>

    @Delete
    fun deleteTask(task: Task)

    @Update
    fun updateTask(task: Task)
}