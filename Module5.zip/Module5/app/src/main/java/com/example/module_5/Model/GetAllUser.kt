package com.example.module_5.Model

import com.google.gson.annotations.SerializedName

data class GetAllUser(
    @SerializedName("student")
    var employee : MutableList<Employee>
)
