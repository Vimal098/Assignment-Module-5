package com.example.module_5.Interface
import com.example.module_5.Model.DeleteResponse
import com.example.module_5.Model.GetAllUser
import com.example.module_5.Model.RegisterResponse
import com.example.module_5.Model.Employee
import retrofit2.Call
import retrofit2.http.Field
import retrofit2.http.FormUrlEncoded
import retrofit2.http.POST

interface ApiService {

    @FormUrlEncoded
    @POST("student.php")
    fun createAccount(
        @Field("flag") flag: Int,
        @Field("name") name: String,
        @Field("email") email: String,
        @Field("mobile") contact:String
    ): Call<RegisterResponse>

    @FormUrlEncoded
    @POST("student.php")
    fun loggedIn(
        @Field("flag") flag: Int,
        @Field("password") password: String,
        @Field("email") email: String,
        ):Call<RegisterResponse>

    @FormUrlEncoded
    @POST("student.php")
    fun getAllUserData(
        @Field("flag") flag: Int,
    ):Call<GetAllUser>

    @FormUrlEncoded
    @POST("student.php")
    fun getSingleUserData(
        @Field("flag") flag: Int,
        @Field("id") id : String
    ):Call<Employee>


    @FormUrlEncoded
    @POST("student.php")
    fun deleteUserData(
        @Field("flag") flag: Int,
        @Field("id") id : String
    ):Call<DeleteResponse>

    @FormUrlEncoded
    @POST("student.php")
    fun UpdateUserData(
        @Field("flag") flag: Int,
        @Field("id") id : String,
        @Field("name") name : String,
        @Field("mobile") contact: String
        ):Call<DeleteResponse>
}