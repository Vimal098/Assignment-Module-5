package com.example.module_5.Model

data class Questions(
    var id : Int,
    var ques : String
)
