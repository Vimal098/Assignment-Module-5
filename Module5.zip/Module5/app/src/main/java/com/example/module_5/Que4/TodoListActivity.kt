package com.example.module_5.Que4

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.module_5.databinding.ActivityTodoListBinding
import java.text.SimpleDateFormat
import java.util.Date
import java.util.Locale

class TodoListActivity : AppCompatActivity() {
    private lateinit var binding : ActivityTodoListBinding
    private lateinit var mAdapter: TodoAdapter
    private lateinit var nAdapter : TodoAdapter
    private var todoList = mutableListOf<Todo>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTodoListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mAdapter = TodoAdapter(this,todoList)
        nAdapter = TodoAdapter(this,todoList)
        binding.completedRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.completedRecyclerView.adapter = mAdapter
       binding.upcomingRecyclerView.layoutManager = LinearLayoutManager(this)
        binding.upcomingRecyclerView.adapter = nAdapter
        //  mAdapter.setItems(taskList)
        mAdapter.itemEditClickListener = { position, todo ->
            var intent = Intent(this, TodoActivity::class.java)
            intent.putExtra("todo", todo)
            startActivity(intent)
        }
        nAdapter.itemEditClickListener = { position, todo ->
            var intent = Intent(this,TodoActivity::class.java)
            intent.putExtra("todo",todo)
            startActivity(intent)
        }

        nAdapter.itemDeleteClickListener = { position, todo ->
            try{
                AppDatabase2.getInstance(this)?.todoDao()!!.deleteItem(todo)
                Toast.makeText(this, "Task deleted", Toast.LENGTH_SHORT).show()
                nAdapter.deleteItem(position)
            }catch (e:Exception){
                e.printStackTrace()
            }
        }
        mAdapter.itemDeleteClickListener = { position, todo ->
            try{
                AppDatabase2.getInstance(this)?.todoDao()!!.deleteItem(todo)
                Toast.makeText(this, "Task deleted", Toast.LENGTH_SHORT).show()
                mAdapter.deleteItem(position)
            }catch (e:Exception){
                e.printStackTrace()
            }
        }
        binding.btnAddTask.setOnClickListener {
            var intent = Intent(this, TodoActivity::class.java)
            startActivity(intent)
        }
    }
    private fun readCompletedTask() {
        val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        todoList = AppDatabase2.getInstance(this)?.todoDao()!!.getAllItems().filter { todo -> todo.date <= currentDate }
            .toMutableList()
        mAdapter.setItems(todoList )
    }

    private fun readUpComingTask() {
        val currentDate = SimpleDateFormat("yyyy-MM-dd", Locale.getDefault()).format(Date())
        todoList = AppDatabase2.getInstance(this)?.todoDao()!!.getAllItems().filter { todo -> todo.date >= currentDate }
            .toMutableList()
        nAdapter.setItems(todoList )
    }


    override fun onResume() {
        super.onResume()
        readCompletedTask()
        readUpComingTask()
    }

}

