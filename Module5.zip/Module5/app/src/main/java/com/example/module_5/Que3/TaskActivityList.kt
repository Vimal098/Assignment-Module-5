package com.example.module_5.Que3

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.module_5.Model.Task
import com.example.module_5.R
import com.example.module_5.databinding.ActivityTaskBinding
import com.example.module_5.databinding.ActivityTaskListBinding

class TaskActivityList : AppCompatActivity() {
    private lateinit var binding: ActivityTaskListBinding
    private lateinit var mAdapter: TaskListAdapter
    private var taskList = mutableListOf<Task>()
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTaskListBinding.inflate(layoutInflater)
        setContentView(binding.root)
        mAdapter = TaskListAdapter(this,taskList)
        binding.recyclerTask.layoutManager = LinearLayoutManager(this)
        binding.recyclerTask.adapter = mAdapter
        //  mAdapter.setItems(taskList)
        mAdapter.itemEditClickListener = { position, task ->
            var intent = Intent(this, TaskActivity::class.java)
            intent.putExtra("task", task)
            taskList.sortBy{it.date+ it.time}
            startActivity(intent)
        }

        mAdapter.itemDeleteClickListener = { position, task ->
            try{
                AppDatabase.getInstance(this)?.taskDao()!!.deleteTask(task)
                Toast.makeText(this, "Task deleted", Toast.LENGTH_SHORT).show()
                mAdapter.deleteItem(position)
            }catch (e:Exception){
                e.printStackTrace()
            }
        }
        binding.btnAddTask.setOnClickListener {
            var intent = Intent(this,TaskActivity::class.java)
            startActivity(intent)
        }
    }
    private fun readTaskList() {

        taskList = AppDatabase.getInstance(this)?.taskDao()!!.getAllTask()
        mAdapter.setItems(taskList)
    }

    override fun onResume() {
        super.onResume()
        readTaskList()
    }


}