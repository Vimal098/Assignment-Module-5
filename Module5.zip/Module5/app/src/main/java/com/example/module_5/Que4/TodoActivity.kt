package com.example.module_5.Que4

import android.os.Build
import android.os.Bundle
import android.widget.Toast
import androidx.appcompat.app.AppCompatActivity
import com.example.module_5.Model.Task
import com.example.module_5.Que3.AppDatabase
import com.example.module_5.databinding.ActivityTaskBinding
import com.example.module_5.databinding.ActivityTodoBinding
import java.lang.Exception
import java.text.SimpleDateFormat
import java.util.Calendar
import java.util.Locale
import kotlin.concurrent.thread

class TodoActivity : AppCompatActivity() {

    lateinit var binding: ActivityTodoBinding
    var db: AppDatabase2? = null
    private var todo: Todo? = null

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityTodoBinding.inflate(layoutInflater)
        setContentView(binding.root)
        db = AppDatabase2.getInstance(this)


        todo = if (Build.VERSION.SDK_INT >= Build.VERSION_CODES.TIRAMISU) {
            intent.getParcelableExtra("todo", Todo::class.java)
        } else {
            intent.getParcelableExtra("todo")
        }

        todo?.let {
            // update
            binding.btnAdd.text = "Update Task"
            binding.etTask.setText(it.task)
           binding.etDate.setText(it.date)

        }

        binding.btnAdd.setOnClickListener {
            var title = binding.etTask.text.toString().trim()
            var date = binding.etDate.text.toString().trim()
            updateRecord(title, date)
        }

    }

    private fun updateRecord(title: String, date: String) {
        var message = ""

        thread(start = true) {

            var todoObject= Todo(
                task = title,
                date = date,
                id = if (todo != null) todo!!.id else 0,
                createdAt = if (todo != null) todo!!.createdAt else System.currentTimeMillis()
            )

            try {
                if(todo!=null){
                    //update
                    db!!.todoDao().updateItem(todoObject)
                    message = "Record updated successfully"
                }else{
                    //add
                    db!!.todoDao().insertItem(todoObject)
                    message = "Record added successfully"
                }

                runOnUiThread {
                    Toast.makeText(this, "$message", Toast.LENGTH_SHORT).show()
                    onBackPressedDispatcher.onBackPressed()
                }
            } catch (e: Exception) {
                e.printStackTrace()
            }
        }

    }


}