package com.example.module_5.Activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.widget.Toast
import com.example.module_5.Model.RegisterResponse
import com.example.module_5.Network.ApiClient
import com.example.module_5.databinding.ActivityLoginBinding
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class LoginActivity : AppCompatActivity() {

    private lateinit var binding: ActivityLoginBinding

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityLoginBinding.inflate(layoutInflater)
        setContentView(binding.root)

        binding.signup.setOnClickListener {
            startActivity(Intent(this,SignUpActivity::class.java))
        }

        binding.btnLogin.setOnClickListener {
            var email = binding.etUsername.text.toString().trim()
            var password = binding.etPassword.text.toString().trim()

            userLoggedIn(email,password)
        }
    }

    private fun userLoggedIn(email: String, password: String) {
        ApiClient.init().loggedIn(6,password,email).enqueue(object :Callback<RegisterResponse>{
            override fun onResponse(
                call: Call<RegisterResponse>,
                response: Response<RegisterResponse>
            ) {
                if (response.isSuccessful){
                    if (password=="123456"){
                        startActivity(Intent(applicationContext, HomeActivity::class.java))
                    }else{
                        Toast.makeText(applicationContext, "Incorrect Password", Toast.LENGTH_SHORT).show()
                    }
                }
            }

            override fun onFailure(call: Call<RegisterResponse>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })
    }
}