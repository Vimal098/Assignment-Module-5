package com.example.module_5.Activities

import android.content.Intent
import androidx.appcompat.app.AppCompatActivity
import android.os.Bundle
import android.view.LayoutInflater
import android.widget.Toast
import androidx.recyclerview.widget.LinearLayoutManager
import com.example.module_5.Adapter.UserItemAdapter
import com.example.module_5.Model.DeleteResponse
import com.example.module_5.Model.GetAllUser
import com.example.module_5.Model.Employee
import com.example.module_5.Network.ApiClient
import com.example.module_5.databinding.ActivityHomeBinding
import com.example.module_5.databinding.UserDialogBinding
import com.google.android.material.bottomsheet.BottomSheetDialog
import retrofit2.Call
import retrofit2.Callback
import retrofit2.Response

class HomeActivity : AppCompatActivity() {

    var employeeList = mutableListOf<Employee>()
    private lateinit var userAdapter: UserItemAdapter
    private lateinit var binding : ActivityHomeBinding
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityHomeBinding.inflate(layoutInflater)
        setContentView(binding.root)


        userAdapter = UserItemAdapter(this,employeeList)

        binding.recyclerView.layoutManager = LinearLayoutManager(this)
        binding.recyclerView.adapter = userAdapter

        fetchUserList()
        userAdapter.itemCardClickListener = {position,user ->
            val intent = Intent(this,SingleUserDetail::class.java)
            intent.putExtra("USER_ID",user.id)
            startActivity(intent)
        }
        userAdapter.itemUpdateClickListener = { position, user ->
            showBottomSheetDialog(user,position)

        }
    }

    private fun showBottomSheetDialog(employee: Employee, position: Int) {
        var bind = UserDialogBinding.inflate(LayoutInflater.from(this))
        bind.etName.setText(employee.name)
        bind.etMobile.setText(employee.contact)
        bind.tvEmail.setText(employee.email)
        var dialog = BottomSheetDialog(this)
        dialog.setContentView(bind.root)
        dialog.show()
        bind.btnUpdate.setOnClickListener {
            employee.name = bind.etName.text.toString()
            employee.contact = bind.etMobile.text.toString()
            updateUserDetail(employee,position)
            dialog.dismiss()
        }
    }

    private fun updateUserDetail(employee: Employee, position: Int) {

        ApiClient.init().UpdateUserData(2, id = employee.id, name = employee.name, contact = employee.contact).enqueue(object :
            Callback<DeleteResponse> {
            override fun onResponse(
                call: Call<DeleteResponse>,
                response: Response<DeleteResponse>
            ) {

                if (response.isSuccessful){
                    var res = response.body()
                    if (res!=null){
                        Toast.makeText(applicationContext, res.message, Toast.LENGTH_SHORT).show()

                        if (res.status == "success"){
                            if (position>=0 && position < employeeList.size){
                                employeeList[position] = employee
                                userAdapter.updateList(employeeList)
                            }
                            startActivity(Intent(applicationContext, HomeActivity::class.java))
                        }
                    }
                }
            }

            override fun onFailure(call: Call<DeleteResponse>, t: Throwable) {
                TODO("Not yet implemented")
            }

        })
    }

    private fun fetchUserList() {
        ApiClient.init().getAllUserData(4).enqueue(object : Callback<GetAllUser> {
            override fun onResponse(call: Call<GetAllUser>, response: Response<GetAllUser>) {

                if(response.isSuccessful){
                    var res = response.body()?.employee
                    res?.let {
                        userAdapter.employeeList = it
                        userAdapter.notifyDataSetChanged()
                    }

                    // Log.d("TAG", "onResponse: $res")
                }

            }

            override fun onFailure(call: Call<GetAllUser>, t: Throwable) {

            }

        })

    }


}