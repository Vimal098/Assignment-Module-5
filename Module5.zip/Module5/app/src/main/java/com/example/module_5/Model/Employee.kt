package com.example.module_5.Model

import android.os.Parcelable
import com.google.gson.annotations.SerializedName
import kotlinx.android.parcel.Parcelize

@Parcelize
data class Employee(
    var id:String,
    var name :String,
    var email : String,
    @SerializedName("mobile")
    var contact:String
):Parcelable
