package com.example.module_5.Model

data class DeleteResponse(
    var status:String,
    var message : String
)
