package com.example.todolist.database

import android.content.Context
import androidx.room.Database
import androidx.room.Room
import androidx.room.RoomDatabase
import com.example.todolist.Dao.NotesDao
import com.example.todolist.Model.Item

@Database(entities = [Item::class], version = 3)
abstract class AppDatabase3: RoomDatabase() {

    // abstract method
    abstract fun todoDao():NotesDao
    companion object {

        private var INSTANCE: AppDatabase3? = null

        fun getInstance(context: Context): AppDatabase3? {
            if (INSTANCE == null) {
                synchronized(this){
                    INSTANCE =
                        Room.databaseBuilder(context, AppDatabase3::class.java, "todo.db").allowMainThreadQueries().build()
                }
            }
            return INSTANCE
        }

    }

}
