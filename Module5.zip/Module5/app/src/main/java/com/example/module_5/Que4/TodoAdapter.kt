package com.example.module_5.Que4

import android.content.Context
import android.view.LayoutInflater
import android.view.ViewGroup
import androidx.recyclerview.widget.RecyclerView
import com.example.module_5.databinding.TodiItemLayoutBinding

class TodoAdapter(var context: Context, var todoList : MutableList<Todo>):
    RecyclerView.Adapter<TodoAdapter.MyViewHolder>() {
    var itemEditClickListener: ((position: Int, todo: Todo) -> Unit)? = null
    var itemDeleteClickListener: ((position: Int, todo: Todo) -> Unit)? = null

    var num: Int = 10

    class MyViewHolder(var binding: TodiItemLayoutBinding) : RecyclerView.ViewHolder(binding.root)

    override fun onCreateViewHolder(
        parent: ViewGroup,
        viewType: Int
    ): TodoAdapter.MyViewHolder {
        var binding = TodiItemLayoutBinding.inflate(LayoutInflater.from(context), parent, false)
        return MyViewHolder(binding)
    }

    override fun onBindViewHolder(holder: MyViewHolder, position: Int) {
        var todo = todoList[position]
        holder.binding.tvTitle.text = todo.task
        holder.binding.tvDate.text = todo.date

        holder.binding.ivEdit.setOnClickListener {
            itemEditClickListener?.invoke(position, todo)
        }

        holder.binding.ivDelete.setOnClickListener {
            itemDeleteClickListener?.invoke(position, todo)
        }
    }

    override fun getItemCount(): Int {
        return todoList.size
    }

    fun setItems(mutableList: MutableList<Todo>) {
        this.todoList = mutableList
        notifyDataSetChanged()
    }

    fun deleteItem(position: Int) {
        todoList.removeAt(position)
        notifyItemRemoved(position)
    }

}